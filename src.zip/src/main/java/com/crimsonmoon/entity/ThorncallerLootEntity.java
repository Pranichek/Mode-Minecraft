package com.crimsonmoon.entity;

import com.crimsonmoon.ModEntities;
import com.crimsonmoon.world.ThorncallerSpawnManager;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.world.World;

/**
 * Лут, который роняет Thorncaller при смерти. Собственный (зарегистрированный
 * в {@link ModEntities#THORNCALLER_LOOT}) тип сущности нужен, чтобы:
 *  1) отследить момент, когда игрок ДЕЙСТВИТЕЛЬНО подобрал предмет — именно
 *     это событие окончательно и навсегда закрывает Thorncaller (см.
 *     {@link ThorncallerSpawnManager});
 *  2) это поведение переживало сохранение/перезагрузку мира — если бы мы
 *     использовали обычный конструктор ItemEntity(World,...), сущность
 *     сериализовалась бы как ванильный "minecraft:item", и после перезапуска
 *     сервера подбор такого предмета уже ничего бы не отслеживал.
 *
 * Никогда не исчезает от старости (см. {@link #setNeverDespawn()}) — иначе,
 * если игроки уйдут и не заберут лут, естественный деспавн предмета навсегда
 * заблокировал бы закрытие боя (Thorncaller — одноразовый босс, и решение,
 * что он побеждён окончательно, принимается только по факту подбора лута).
 */
public class ThorncallerLootEntity extends ItemEntity {

    public ThorncallerLootEntity(EntityType<? extends ItemEntity> type, World world) {
        super(type, world);
        this.setNeverDespawn();
    }

    /** Создаёт и сразу спавнит лут Thorncaller в указанной точке. */
    public static ThorncallerLootEntity spawn(ServerWorld world, double x, double y, double z, ItemStack stack) {
        ThorncallerLootEntity loot = ModEntities.THORNCALLER_LOOT.create(world);
        if (loot == null) {
            return null;
        }
        loot.setStack(stack);
        loot.refreshPositionAndAngles(x, y, z, 0.0f, 0.0f);
        loot.setVelocity(0.0, 0.15, 0.0);
        world.spawnEntity(loot);
        return loot;
    }

    @Override
    public void onPlayerCollision(PlayerEntity player) {
        boolean hadStack = !this.getStack().isEmpty();
        int countBefore = hadStack ? this.getStack().getCount() : 0;

        super.onPlayerCollision(player);

        // подобрано целиком (сущность удалена) либо стак уменьшился —
        // в обоих случаях это и есть окончательное подтверждение победы над боссом
        boolean removedEntirely = this.isRemoved();
        boolean stackShrank = hadStack && !this.getStack().isEmpty() && this.getStack().getCount() < countBefore;

        if (!this.getWorld().isClient && (removedEntirely || stackShrank) && this.getWorld() instanceof ServerWorld serverWorld) {
            ThorncallerSpawnManager.onLootCollected(serverWorld, this.getUuid());
        }
    }
}
