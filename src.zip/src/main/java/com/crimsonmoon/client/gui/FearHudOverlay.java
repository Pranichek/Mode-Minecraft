package com.crimsonmoon.client.gui;

import com.crimsonmoon.FearManager;
import com.crimsonmoon.entity.BloodwalkerEntity;
import com.crimsonmoon.entity.NightmareEntity;
import com.crimsonmoon.entity.ThorncallerEntity;
import com.crimsonmoon.entity.WatcherEntity;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.world.LightType;
import java.util.List;

/**
 * HUD-шкала страха. Раньше показывала мгновенную дистанцию до ближайшего
 * Bloodwalker и была чисто декоративной. Теперь страх — это игровой ресурс
 * ("заряд" для способностей Кровавого посоха/булавы, см. {@link FearManager}),
 * поэтому и HUD ведёт себя как накопительный измеритель: заполняется медленно
 * (не мгновенно, как раньше) и по тем же условиям, что считает авторитетный
 * сервер в {@link FearManager} — рядом опасность (любой из пугающих мобов
 * мода) и/или темнота. Настоящий расход шкалы (когда используются
 * способности) авторитетно считает сервер; здесь — визуальное зеркало тех же
 * правил для отзывчивого HUD без отдельного сетевого канала синхронизации.
 *
 * Полоса перенесена в нижнюю часть экрана (над хотбаром), чтобы не перекрывать
 * полосу здоровья/опыта и боссбар вверху.
 */
public class FearHudOverlay implements HudRenderCallback {
    private static final double DETECTION_RADIUS = 16.0;
    private static final int DARK_LIGHT_THRESHOLD = 7;

    // те же (сознательно медленные) темпы, что и у серверного FearManager —
    // чтобы HUD визуально совпадал с реальным темпом накопления ресурса
    private static final float PROXIMITY_GAIN_PER_TICK = 0.06f;
    private static final float DARKNESS_GAIN_PER_TICK = 0.015f;
    private static final float SAFE_DECAY_PER_TICK = 0.02f;

    private static final Identifier FEAR_ICON = new Identifier("crimsonmoon", "textures/gui/fear_vignette.png");

    /** Накопленное значение 0..100, обновляется раз в клиентский тик — см. {@link #tickClientFear}. */
    public static float currentFear = 0.0f;
    public static float currentPulse = 0.0f;

    /** Регистрирует накопление {@link #currentFear} раз в клиентский тик (а не за кадр рендера). */
    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null || client.isPaused()) {
                return;
            }
            tickClientFear(client);
        });
    }

    @Override
    public void onHudRender(DrawContext context, float tickDelta) {
        MinecraftClient client = MinecraftClient.getInstance();

        if (client.player == null || client.world == null) {
            return;
        }

        float fearPercentage = currentFear / FearManager.MAX_FEAR;
        if (fearPercentage <= 0.0f) {
            currentPulse = 0.0f;
            return;
        }

        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();

        long currentTime = System.currentTimeMillis();
        float pulseSpeed = 300.0f - (fearPercentage * 200.0f);
        float pulse = (float) ((Math.sin(currentTime / pulseSpeed) + 1.0) / 2.0);
        currentPulse = pulse;

        float finalAlpha = fearPercentage * pulse * 0.8f;

        context.getMatrices().push();

        if (fearPercentage > 0.7f) {
            context.getMatrices().translate(screenWidth / 2.0f, screenHeight / 2.0f, 0);
            float scale = 1.0f + (pulse * 0.15f);
            context.getMatrices().scale(scale, scale, 1.0f);
            context.getMatrices().translate(-screenWidth / 2.0f, -screenHeight / 2.0f, 0);
        }

        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, finalAlpha);
        context.drawTexture(FEAR_ICON, 0, 0, -90, 0.0f, 0.0f, screenWidth, screenHeight, screenWidth, screenHeight);
        RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
        RenderSystem.disableBlend();

        context.getMatrices().pop();

        // === полоса — теперь внизу экрана, над хотбаром ===
        int barWidth = 120;
        int barHeight = 8;
        int x = (screenWidth / 2) - (barWidth / 2);
        int y = screenHeight - 51; // чуть выше хотбара (хотбар ~22px + отступ под опыт/эффекты)
        int filledWidth = (int) (barWidth * fearPercentage);

        context.fill(x, y, x + barWidth, y + barHeight, 0xFF444444);
        context.fill(x, y, x + filledWidth, y + barHeight, 0xFF990000);

        String text = "Відчуття страху";
        int textWidth = client.textRenderer.getWidth(text);
        context.drawText(client.textRenderer, text, x + (barWidth - textWidth) / 2, y - 10, 0xFFAAAAAA, true);
    }

    /**
     * Клиентское "зеркало" правил {@link FearManager#tick} — накапливает
     * {@link #currentFear} медленно, а не мгновенно подставляет текущую
     * дистанцию до моба, как было раньше.
     */
    private static void tickClientFear(MinecraftClient client) {
        Box searchBox = client.player.getBoundingBox().expand(DETECTION_RADIUS);
        List<Entity> nearby = client.world.getOtherEntities(client.player, searchBox, FearHudOverlay::isFearSource);

        double closest = Double.MAX_VALUE;
        for (Entity mob : nearby) {
            double dist = client.player.distanceTo(mob);
            if (dist < closest) {
                closest = dist;
            }
        }

        boolean inDarkness = client.world.getLightLevel(LightType.BLOCK, client.player.getBlockPos()) <= DARK_LIGHT_THRESHOLD
            && client.world.getLightLevel(LightType.SKY, client.player.getBlockPos()) <= DARK_LIGHT_THRESHOLD;

        float gain = 0.0f;
        if (closest <= DETECTION_RADIUS) {
            double proximity = 1.0 - (closest / DETECTION_RADIUS);
            gain += (float) (PROXIMITY_GAIN_PER_TICK * proximity);
        }
        if (inDarkness) {
            gain += DARKNESS_GAIN_PER_TICK;
        }

        if (gain > 0.0f) {
            currentFear = Math.min(FearManager.MAX_FEAR, currentFear + gain);
        } else if (currentFear > 0.0f) {
            currentFear = Math.max(0.0f, currentFear - SAFE_DECAY_PER_TICK);
        }
    }

    private static boolean isFearSource(Entity entity) {
        return entity instanceof ThorncallerEntity
            || entity instanceof BloodwalkerEntity
            || entity instanceof NightmareEntity
            || entity instanceof WatcherEntity;
    }
}
