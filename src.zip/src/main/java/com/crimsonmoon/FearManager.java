package com.crimsonmoon;

import com.crimsonmoon.entity.BloodwalkerEntity;
import com.crimsonmoon.entity.NightmareEntity;
import com.crimsonmoon.entity.ThorncallerEntity;
import com.crimsonmoon.entity.WatcherEntity;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.LightType;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Шкала страха как игровой ресурс ("заряд").
 *
 * Раньше {@code FearHudOverlay} просто мгновенно отражал дистанцию до
 * ближайшего Bloodwalker — чисто визуальный эффект без последствий для
 * геймплея. Теперь это накопительный ресурс, которым игрок платит за
 * способности Кровавого посоха и Кровавой булавы (см. {@code BloodStaffItem},
 * {@code BloodMaceItem}).
 *
 * Заполнение НАМЕРЕННО медленное (в очках/тик, а не мгновенное "%
 * от дистанции", как было раньше) и требует реальной угрозы:
 *  - поблизости (в радиусе {@link #FEAR_SOURCE_RADIUS}) есть один из пугающих
 *    мобов мода (Thorncaller, Bloodwalker, Nightmare, Watcher) — чем ближе, тем
 *    быстрее растёт страх;
 *  - и/или игрок стоит в темноте.
 * Когда угроз нет, шкала медленно затухает сама.
 */
public class FearManager {

    public static final float MAX_FEAR = 100.0f;

    private static final double FEAR_SOURCE_RADIUS = 16.0;
    private static final int DARK_LIGHT_THRESHOLD = 7;

    // Сознательно небольшие числа — шкала теперь наполняется намного медленнее,
    // чем раньше (раньше "заполнение" было мгновенным пересчётом дистанции).
    private static final float PROXIMITY_GAIN_PER_TICK = 0.06f; // на минимальной дистанции до источника
    private static final float DARKNESS_GAIN_PER_TICK = 0.015f;
    private static final float SAFE_DECAY_PER_TICK = 0.02f;

    private static final Map<UUID, Float> fear = new HashMap<>();

    private FearManager() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                tick(player);
            }
        });
    }

    public static float get(PlayerEntity player) {
        return fear.getOrDefault(player.getUuid(), 0.0f);
    }

    public static float getPercent(PlayerEntity player) {
        return MathHelper.clamp(get(player) / MAX_FEAR, 0.0f, 1.0f);
    }

    /** Пытается потратить {@code amount} страха. Возвращает true, если хватило и трата прошла. */
    public static boolean consume(PlayerEntity player, float amount) {
        if (player.isCreative() || player.isSpectator()) {
            return true;
        }
        float current = get(player);
        if (current + 1.0e-4f < amount) {
            return false;
        }
        set(player.getUuid(), current - amount);
        return true;
    }

    public static boolean hasAtLeast(PlayerEntity player, float amount) {
        return player.isCreative() || player.isSpectator() || get(player) >= amount;
    }

    private static void set(UUID id, float value) {
        fear.put(id, MathHelper.clamp(value, 0.0f, MAX_FEAR));
    }

    private static void tick(ServerPlayerEntity player) {
        World world = player.getWorld();
        float current = get(player);

        double closest = closestFearSourceDistance(player);
        boolean inDarkness = world.getLightLevel(LightType.BLOCK, player.getBlockPos()) <= DARK_LIGHT_THRESHOLD
            && world.getLightLevel(LightType.SKY, player.getBlockPos()) <= DARK_LIGHT_THRESHOLD;

        float gain = 0.0f;
        if (closest <= FEAR_SOURCE_RADIUS) {
            double proximity = 1.0 - (closest / FEAR_SOURCE_RADIUS);
            gain += (float) (PROXIMITY_GAIN_PER_TICK * proximity);
        }
        if (inDarkness) {
            gain += DARKNESS_GAIN_PER_TICK;
        }

        if (gain > 0.0f) {
            set(player.getUuid(), current + gain);
        } else if (current > 0.0f) {
            set(player.getUuid(), current - SAFE_DECAY_PER_TICK);
        }
    }

    private static double closestFearSourceDistance(ServerPlayerEntity player) {
        Box searchBox = player.getBoundingBox().expand(FEAR_SOURCE_RADIUS);
        List<Entity> sources = player.getWorld().getOtherEntities(player, searchBox, FearManager::isFearSource);

        double closest = Double.MAX_VALUE;
        for (Entity source : sources) {
            double dist = player.distanceTo(source);
            if (dist < closest) {
                closest = dist;
            }
        }
        return closest;
    }

    private static boolean isFearSource(Entity entity) {
        return entity instanceof ThorncallerEntity
            || entity instanceof BloodwalkerEntity
            || entity instanceof NightmareEntity
            || entity instanceof WatcherEntity;
    }
}
